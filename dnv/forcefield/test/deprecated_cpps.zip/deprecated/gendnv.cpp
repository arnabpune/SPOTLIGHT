#include <iostream>
#include <string>
#include <map>
#include <vector>
#include <iterator>
#include <fstream>
#include <algorithm>
#include <sstream>

using namespace std;

/*
||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
|############################################################################|
|#######################Read, parse a pdb file###############################|
|########################And create a DNV file##############################|
|############################################################################|
||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
*/

string trim(string str) {
    //this function will remove spaces from either sides of a string
    str.erase(0, str.find_first_not_of(' '));
    str.erase(str.find_last_not_of(' ')+1);
    return str;
}

string trimtabs(string str) {
    //this function will remove tabs from either side of the string
    str.erase(0, str.find_first_not_of('\t'));
    str.erase(str.find_last_not_of('\t')+1);
    return str;
}

string trimsemicolon(string str) {
    //this function will remove commented out portion from a string
    //in this case, comments start from a ';'
    str = str.substr(0, str.find(";", 0));
    return str;
}

vector<string> tokenizebytabs(string str) {
    //this function will tokenize a string where words are separated by single tabs
    stringstream ss(str);
    string s;
    vector<string> retVec;

    while (getline(ss, s, '\t')) {
        retVec.push_back(s);
    }
    return retVec;
}

struct dataFromPDB {
    string pdb_atom; //atom name from pdb
    string xcoord;
    string ycoord;
    string zcoord;
    string elementID; //element symbol from pdb
};

struct dataFromRTP {
    string pdb_atom; //atom name as in pdb
    string atom_type; //atom type as in rtp
    string charge; //charge from rtp
};


/*
||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
|############################################################################|
|#######################Main Loop for read-write#############################|
|######################operations and rtp parsing############################|
|############################################################################|
||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
*/

int main(int argc, char *argv[])
{
    ifstream rtp_in;
    ifstream pdb_in;
    ifstream list_in;
    ofstream dnv_out;

    //vector<string> ResNamesSet;
    map<string, vector<dataFromPDB>> PDBDataPerResNumber;
    map<string, string> ResNamesPerResNumber;
    map<string, vector<dataFromRTP>> RTPDataPerResName;

    string path_to_rtp;
    string path_to_dnv;
    string path_to_pdb;
    string path_to_reslist;


    if (argc == 1) { // no command line arguments are given, go for default files!

        //the default pdb file will be in.pdb
        //the default rtp file will be in.rtp
        //the default dnv file will be out.dnv
        //the default list will be reslist.txt

        pdb_in.open("prot.pdb");
        rtp_in.open("aminoacids.rtp");
        list_in.open("reslist.txt");

        dnv_out.open("out.dnv", ios::trunc);

        path_to_rtp = "in.rtp";
        path_to_dnv = "out.dnv";
        path_to_reslist = "reslist.txt";
        path_to_pdb = "in.pdb";
        
        if(!pdb_in) {
            cout << "Error in opening in.pdb! Exiting...\n";
            exit(1);
        }
        if(!rtp_in) {
            cout << "Error in opening in.rtp! Exiting...\n";
            exit(1);
        }
        if(!list_in) {
            cout << "Error in opening reslist.txt! Exiting...\n";
            exit(1);
        }
        if(!dnv_out) {
            cout << "Error in opening out.dnv! Exiting...\n";
            exit(1);
        }
    }
    else {
        if(argc%2 != 1) {
            cout << "Incorrect set of arguments! Exiting...\n";
            exit(1);
        }
        bool openedPDB = false, openedRTP = false, openedDNV = false, openedLIST = false;
        //cout << argc << endl;
        for(int i = 1; i < argc; i+=2) {
            string str;
            str = argv[i];
            if(str.compare("-p") == 0) {
                //string path_to_pdb;
                path_to_pdb = argv[i+1];
                pdb_in.open(path_to_pdb);
                if(!pdb_in) {
                    cout << "Error opening pdb file! Please check your given path! Exiting...\n";
                    exit(1);
                }
                else {
                    cout << "Opened pdb file successfully!\n";
                    openedPDB = true;
                }
            }
            else if(str.compare("-r") == 0) {
                //string path_to_rtp;
                path_to_rtp = argv[i+1];
                rtp_in.open(path_to_rtp);
                if(!pdb_in) {
                    cout << "Error opening rtp file! Please check your given path! Exiting...\n";
                    exit(1);
                }
                else {
                    cout << "Opened rtp file successfully!\n";
                    openedRTP = true;
                }
            }
            else if(str.compare("-o") == 0) {
                //string path_to_dnv;
                path_to_dnv = argv[i+1];
                dnv_out.open(path_to_dnv, ios::trunc);
                if(!pdb_in) {
                    cout << "Error opening dnv file! Please check your given path! Exiting...\n";
                    exit(1);
                }
                else {
                    cout << "Opened dnv file successfully!\n";
                    openedDNV = true;
                }
            }
            else if(str.compare("-l") == 0) {
                //string path_to_list;
                path_to_reslist = argv[i+1];
                list_in.open(path_to_reslist);
                if(!pdb_in) {
                    cout << "Error opening list file! Please check your given path! Exiting...\n";
                    exit(1);
                }
                else {
                    cout << "Opened list file successfully!\n";
                    openedLIST = true;
                }
            }
        }
        if(openedPDB == false) {
            pdb_in.open("in.pdb");
            if(!pdb_in) {
                cout << "Error in opening in.pdb! Exiting...\n";
                exit(1);
            }
            else {
                path_to_pdb = "in.pdb";
                cout << "Opened pdb file successfully!\n";
                openedPDB = true;
            }
        }
        if(openedDNV == false) {
            dnv_out.open("out.dnv", ios::trunc);
            if(!dnv_out) {
                cout << "Error in opening out.dnv! Exiting...\n";
                exit(1);
            }
            else {
                path_to_dnv = "out.dnv";
                cout << "Opened dnv successfully!\n";
                openedDNV = true;
            }
        }
        if(openedLIST == false) {
            list_in.open("reslist.txt");
            if(!list_in) {
                cout << "Error in opening reslist.txt! Exiting...\n";
                exit(1);
            }
            else {
                path_to_reslist = "reslist.txt";
                cout << "Opened reslist file successfully!\n";
                openedLIST = true;
            }
        }
        if(openedRTP == false) {
            rtp_in.open("in.rtp");
            if(!list_in) {
                cout << "Error in opening in.rtp! Exiting...\n";
                exit(1);
            }
            else {
                path_to_rtp = "in.rtp";
                cout << "Opened rtp file successfully!\n";
                openedRTP = true;
            }
        }
    }

    //cout << "yo\n";

    //EDITED BY RITU: ADDING A STRING VECTOR FOR THE STUPID NUMBERS
    vector<string> allresnums;
    //files opened, now go for reading the pdb and getting the residue names
    for(string line; getline(pdb_in, line);) {
        string record;
        record = line.substr(0, 6);
        record = trim(record);
        if((record.compare("ATOM") == 0) || (record.compare("HETATM") == 0)) {
            //cout << "here\n";
            string residue_name;
            residue_name = line.substr(17, 3); 
            residue_name = trim(residue_name);

            string residue_number;
            residue_number = line.substr(22, 4);
            residue_number = trim(residue_number);
            ResNamesPerResNumber[residue_number] = residue_name;

            dataFromPDB data;

            string pdb_atom_name;
            pdb_atom_name = line.substr(12, 4);
            pdb_atom_name = trim(pdb_atom_name);
            data.pdb_atom = pdb_atom_name;

            string xcoord;
            xcoord = line.substr(30, 8);
            xcoord = trim(xcoord);
            data.xcoord = xcoord;

            string ycoord;
            ycoord = line.substr(38, 8);
            ycoord = trim(ycoord);
            data.ycoord = ycoord;

            string zcoord;
            zcoord = line.substr(46, 8);
            zcoord = trim(zcoord);
            data.zcoord = zcoord;

            string elementID;
            elementID = line.substr(76, 2);
            elementID = trim(elementID);
            data.elementID = elementID;

            PDBDataPerResNumber[residue_number].push_back(data);
            //EDITED BY RITU: STORE THE STUPID NUMBERS IN THE VECTOR
            allresnums.push_back(residue_number);
            //cout<<"pushing back "<<residue_number<<", allresnum size = "<<allresnums.size()<<endl;
        }
    }
    std::sort(allresnums.begin(), allresnums.end());
    allresnums.erase(std::unique(allresnums.begin(), allresnums.end()), allresnums.end());

    cout << "pdb processed successfully\n";


    for(auto elem : ResNamesPerResNumber) {
        string resname;
        resname = elem.second;
        resname = "[ " + resname + " ]";
        bool foundres = false;
        bool foundatomstag = false;
        bool gettingatomdata = false;
        ifstream temprtp;
        //temp = rtp_in;
        temprtp.open(path_to_rtp);
        for(string line; getline(temprtp, line);) {
            line = trim(line);
            //line.erase(line.find_first_of(';')+1);
            line = trimsemicolon(line);
            line = trim(line);
            line = trimtabs(line);
            if(line.compare(resname) == 0) {
                //cout << "yes " << resname << " " << endl;
                foundres = true;
            }
            else if((line.compare("[ atoms ]") == 0) && (foundres == true)) {
                //cout << "found atoms\n";
                foundatomstag = true;
            }
            else if(foundres == true && foundatomstag == true && line[0] == '[') {
                foundres = false;
                foundatomstag = false;
                gettingatomdata = false;
                temprtp.close();
                break;
            }
            else if((foundres == true) && (foundatomstag == true) && line.compare("[ atoms ]") != 0)
            {
                vector<string> temp;
                temp = tokenizebytabs(line);
                dataFromRTP data;
                data.pdb_atom = temp[0];
                data.atom_type = temp[1];
                //data.charge = temp.back();
                data.charge = temp[2];
                gettingatomdata = true;
                RTPDataPerResName[resname].push_back(data);
                //cout << line << endl;
            }
        }
    }


    for(string line; getline(list_in, line);) {
        string resname;
        resname = ResNamesPerResNumber[line];
        resname = "[ " + resname + " ]";
        vector<dataFromPDB> pdbdata;
        vector<dataFromRTP> rtpdata;
        pdbdata = PDBDataPerResNumber[line];
        rtpdata = RTPDataPerResName[resname];
        for(auto pdbobj : pdbdata) {
            string pdbatom = pdbobj.pdb_atom;
            for(auto rtpobj : rtpdata) {
                if(pdbatom.compare(rtpobj.pdb_atom) == 0) {
                    dnv_out << rtpobj.atom_type << " " << pdbobj.xcoord << " " << pdbobj.ycoord << " " << pdbobj.zcoord << " " << rtpobj.charge << " " << pdbobj.elementID << "\n";
                    break;
                }
            }
        }
    }
    //cout<<"here"<<endl;
    //EDITED BY RITU: PRINT EVERYTHING IN THE PROTEIN AND CLOSE THE DAMN BUFFER
    dnv_out.close();
    ofstream dnv_out2; dnv_out2.open("./protein.dnv", fstream::out);
    vector<string>::iterator itsn; itsn = allresnums.begin();
    while(itsn != allresnums.end()){
        string line2; line2 = *itsn;
        //cout<<line2<<endl;
        string resname;
        resname = ResNamesPerResNumber[line2];
        resname = "[ " + resname + " ]";
        vector<dataFromPDB> pdbdata;
        vector<dataFromRTP> rtpdata;
        pdbdata = PDBDataPerResNumber[line2];
        rtpdata = RTPDataPerResName[resname];
        for(auto pdbobj : pdbdata) {
            string pdbatom = pdbobj.pdb_atom;
            for(auto rtpobj : rtpdata) {
                if(pdbatom.compare(rtpobj.pdb_atom) == 0) {
                    dnv_out2 << rtpobj.atom_type << " " << pdbobj.xcoord << " " << pdbobj.ycoord << " " << pdbobj.zcoord << " " << rtpobj.charge << " " << pdbobj.elementID << "\n";
                    break;
                }
            }
        }
        ++itsn;
    }
    dnv_out2.close();
    return 0;
}
