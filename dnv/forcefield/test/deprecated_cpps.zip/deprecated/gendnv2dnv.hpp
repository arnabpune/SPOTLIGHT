#ifndef GENDNVDNV_HPP
#define GENDNVDNV_HPP
#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <vector>
#include <math.h>
#include <map>
#include "../Eigen337/Eigen/Core"
#include "../Eigen337/Eigen/Dense"

using namespace std;

/*
|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
|###############################################################################|
|#######################Read and load parameters like###########################|
|####################Mass,Charge,Valency,Sigma and Epsilon######################|
|###############################################################################|
|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
*/

map<string,pair<int,double>> load_valency(string atomtypesfilename){
    map<string,pair<int,double>> finalmap;
    ifstream ifile; ifile.open(atomtypesfilename);
    string line;
    while(getline(ifile,line)){
        if( (line.find("#")!=string::npos) || (line.find(";")!=string::npos) ){
            continue;
        }
        else{
            stringstream ss(line);
            string atomtype; double mass; int valency;
            ss>>atomtype>>mass>>valency;
            pair<int,double> valmasspair; valmasspair = make_pair(valency,mass);
            pair<string,pair<int,double>> finalpair; finalpair = make_pair(atomtype,valmasspair);
            finalmap.insert(finalpair);
        }
    }
    ifile.close();
    return finalmap;
}

map<string,Eigen::Vector3d> load_sigepscharge(string nonbondedfilename){
    map<string,Eigen::Vector3d> finalmap;
    ifstream ifile; ifile.open(nonbondedfilename);
    string line;
    while(getline(ifile,line)){
        if( (line.find("#")!=string::npos) || (line.find(";")!=string::npos) ){
            continue;
        }
        else{
            stringstream ss(line);
            string atomtype; int atnumber; double mass,sigma,epsilon,charge;
            ss>>atomtype>>mass>>charge>>sigma>>epsilon;
            Eigen::Vector3d sigepscharge(sigma,epsilon,charge);
            pair<string,Eigen::Vector3d> finalpair; finalpair = make_pair(atomtype,sigepscharge);
            finalmap.insert(finalpair);
        }
    }
    ifile.close();
    return finalmap;
}

/*
|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
|###############################################################################|
|#######################Read and convert a pre-dnv file#########################|
|##############################to a final dnv file##############################|
|###############################################################################|
|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
*/

void create_final_inputfile(string abhishekfile, map<string,pair<int,double>> typevalency, map<string,Eigen::Vector3d> sigepscharge, string outfilename="INPUT.txt"){
    string line; int Nline = 0;
    ifstream ifile; ifile.open(abhishekfile);
    vector<string> lines;
    while(getline(ifile,line)){
        if((line.find("#")!=string::npos) || (line.find(";")!=string::npos)){
            continue;
        }
        else{
            stringstream ss(line);
            string readtype,readname; double x,y,z,charge;
            ss>>readtype>>x>>y>>z>>charge>>readname;
            pair<int,double> valmass;
            Eigen::Vector3d sigepsq;
            map<string,pair<int,double>>::iterator ita; ita = typevalency.find(readtype);
            map<string,Eigen::Vector3d>::iterator itb; itb = sigepscharge.find(readtype);
            if( (ita == typevalency.end()) ){
                cout<<"Could not find valency for atomtype: "<<readtype<<endl;
                continue;
            }
            else if( (itb == sigepscharge.end()) ){
                cout<<"Could not find sigma, epsilon and charge for atomtype: "<<readtype<<endl;
                continue;
            }
            else{
                valmass = ita->second; sigepsq = itb->second;
                int valency = get<0>(valmass); double mass = get<1>(valmass);
                double sigma,epsilon,q;
                sigma = sigepsq(0); epsilon = sigepsq(1); q = sigepsq(2);
                string printableline = readtype+'\t'+to_string(x)+'\t'+to_string(y)+'\t'+to_string(z)+'\t'+to_string(valency)+'\t'+to_string(mass)+'\t'+to_string(charge)+'\t'+to_string(sigma)+'\t'+to_string(epsilon)+'\t'+to_string((sigma/2.0));
                lines.push_back(printableline);
                Nline = Nline + 1;
            }
        }
    }
    ifile.close();
    //print all the lines
    ofstream ofile; ofile.open(outfilename,ofstream::app);
    ofile<<Nline<<endl;
    vector<string>::iterator it; it = lines.begin();
    while(it != lines.end()){
        string currline; currline = *it;
        ofile<<currline<<endl;
        ++it;
    }
    ofile.close();
    //FUTURE: IMPLEMENT A DIRECT BOND RECOGNITION CODE HERE
}
#endif
