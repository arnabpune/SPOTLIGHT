#include "./gendnv2dnv.hpp"

using namespace std;

std::string exefolder="/home/venkata/cpp/transfer/forcefield";
int main(){
    string atomtypesfilename = exefolder+"/charmm27/atomtypes.atp";
    string nonbondfilename = exefolder+"/charmm27/nonbonded.itp";
    string abhishekfilename = "./out.dnv"; string proteinfilename = "./protein.dnv";
    map<string,pair<int,double>> valmap; valmap = load_valency(atomtypesfilename);
    map<string,Eigen::Vector3d> sigepscharge; sigepscharge = load_sigepscharge(nonbondfilename);
    create_final_inputfile(abhishekfilename, valmap, sigepscharge);
    create_final_inputfile(proteinfilename, valmap, sigepscharge,"PROT.txt");
    return 0;
}
