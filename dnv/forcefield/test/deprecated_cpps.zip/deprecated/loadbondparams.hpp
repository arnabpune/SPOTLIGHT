#ifndef LOADBONDPARAMS_HPP
#define LOADBONDPARAMS_HPP
#include "./gendnv2dnv.hpp"

using namespace std;

/*
|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
|###############################################################################|
|#######################Read and load parameters like###########################|
|####################bonds,angles,dihedrals and impropers#######################|
|###############################################################################|
|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
*/

/*
We will return the bond types, angles, dihedrals and impropers based on the given atom being the origin
*/

vector<tuple<string,string,Eigen::Vector2d>> find_bonds_for(string atomtype, string ff_folder){
    vector<tuple<string,string,Eigen::Vector2d>> finalvec;
    ifstream ifile; ifile.open((ff_folder+"/bondtypes.itp"));
    string line;
    while(getline(ifile,line)){
        if( (line.find(";") != string::npos) || (line.find("#") != string::npos) ){ continue; }
        else{
            stringstream ss(line);
            string typea,typeb; double b0,kb;
            ss>>typea>>typeb>>b0>>kb;
            if( (atomtype.compare(typea)==0) ){
                Eigen::Vector3d v(b0,kb);
                tuple<string,string,Eigen::Vector2d> t; t = make_tuple(atomtype,typeb,v);
                finalvec.push_back(t);
            }
            else if( (atomtype.compare(typeb)==0) ){
                Eigen::Vector3d v(b0,kb);
                tuple<string,string,Eigen::Vector2d> t; t = make_tuple(atomtype,typea,v);
                finalvec.push_back(t);
            }
            else;//do nothing and continue
        }
    }
    return finalvec;
}

vector<tuple<string,string,string,Eigen::Vector4d>> find_bends_for(string atomtype, string ff_folder){
    vector<tuple<string,string,string,Eigen::Vector4d>> finalvec;
    ifstream ifile; ifile.open((ff_folder+"/angletypes.itp"));
    string line;
    while(getline(ifile,line)){
        if( (line.find(";") != string::npos) || (line.find("#") != string::npos) ){ continue; }
        else{
            stringstream ss(line);
            string typea,typeb,typec; double tht0,ktht,w0,kw;
            ss>>typea>>typeb>>typec>>tht0>>ktht>>w0>>kw;
            if( (atomtype.compare(typea)==0) ){
                Eigen::Vector4d v(tht0,ktht,w0,kw);
                tuple<string,string,string,Eigen::Vector4d> t; t = make_tuple(atomtype,typeb,typec,v);
                finalvec.push_back(t);
            }
            else if( (atomtype.compare(typec)==0) ){
                Eigen::Vector4d v(tht0,ktht,w0,kw);
                tuple<string,string,string,Eigen::Vector4d> t; t = make_tuple(atomtype,typeb,typea,v);
                finalvec.push_back(t);
            }
            else;//do nothing and continue
        }
    }
    return finalvec;
}

vector<tuple<string,string,string,string,Eigen::Vector3d>> find_propertorsions_for(string atomtype, string ff_folder){
    vector<tuple<string,string,string,string,Eigen::Vector3d>> finalvec;
    ifstream ifile; ifile.open((ff_folder+"/dihedraltypes.itp"));
    string line;
    while(getline(ifile,line)){
        if( (line.find(";") != string::npos) || (line.find("#") != string::npos) ){ continue; }
        else{
            stringstream ss(line);
            string typea,typeb,typec,typed; double phi0,cphi; int n;
            ss>>typea>>typeb>>typec>>typed>>phi0>>cphi>>n;
            double nn = ((double)n);
            if( (atomtype.compare(typea)==0) ){
                Eigen::Vector3d v(phi0,cphi,nn);
                tuple<string,string,string,string,Eigen::Vector3d> t; t = make_tuple(atomtype,typeb,typec,typed,v);
                finalvec.push_back(t);
            }
            else if( (atomtype.compare(typed)==0) ){
                Eigen::Vector3d v(phi0,cphi,nn);
                tuple<string,string,string,string,Eigen::Vector3d> t; t = make_tuple(atomtype,typec,typeb,typea,v);
                finalvec.push_back(t);
            }
            else;//do nothing and continue
        }
    }
    return finalvec;
}

vector<tuple<string,string,string,string,Eigen::Vector2d>> find_impropertorsions_for(string atomtype, string ff_folder){
    vector<tuple<string,string,string,string,Eigen::Vector2d>> finalvec;
    ifstream ifile; ifile.open((ff_folder+"/impropertypes.itp"));
    string line;
    while(getline(ifile,line)){
        if( (line.find(";") != string::npos) || (line.find("#") != string::npos) ){ continue; }
        else{
            stringstream ss(line);
            string typea,typeb,typec,typed; double chi0,kchi;
            ss>>typea>>typeb>>typec>>typed>>chi0>>kchi;
            if( (atomtype.compare(typea)==0) ){
                Eigen::Vector2d v(chi0,kchi);
                tuple<string,string,string,string,Eigen::Vector2d> t; t = make_tuple(atomtype,typeb,typec,typed,v);
                finalvec.push_back(t);
            }
            else;//do nothing and continue
        }
    }
    return finalvec;
}
#endif
