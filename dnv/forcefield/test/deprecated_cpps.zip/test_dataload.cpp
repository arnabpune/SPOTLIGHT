#include "graph/Molecule.hpp"
#include <iostream>
using namespace std;

int main()
{
	cout << "Loading data\n";
	Molecule::loadBondParameters();
}
