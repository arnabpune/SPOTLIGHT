#include "../forcefield.hpp"

int main()
{
	collateDataFiles("atomtypes.atp","nonbonded.calc.itp");
	ForceField finalff("final_ff_parameters.ffin");
	Atom* ta=finalff.getAtom("CA");
	cout << ta->toString()<<"\t"<<ta->seek_sigma()<<"\t"<<ta->seek_epsilon()<<"\n";
}
